class Mammal
  attr_accessor :health
  def initialize
    @health = 150
    self
  end
  def dispHp
    p "Health: #{@health}"
    self
  end
end
