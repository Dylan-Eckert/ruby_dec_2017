require_relative 'mammal'

class Lion < Mammal
  def initialize
    @health = 170
  end
  def fly
    @health -= 10
    self
  end
  def atktwn
    @health -= 50
    self
  end
  def eat
    @health += 20
    self
  end
  def dispHp
    super
    puts "I am a LION"
  end
end
Lion.new.atktwn.atktwn.atktwn.eat.eat.fly.fly.dispHp
