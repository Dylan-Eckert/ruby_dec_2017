require_relative 'human'

class Ninja < Human
  def initialize
    super
    @stealth = 175
  end
  def steal(obj)
    attack(obj)
    @health += 10
  end
  def getaway
    @health -=15
  end
end

bill = Ninja.new
phil = Ninja.new
p bill
p phil
bill.steal(phil)
p bill
p phil
phil.getaway
p phil
