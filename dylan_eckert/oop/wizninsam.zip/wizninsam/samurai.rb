require_relative 'human'

class Samurai < Human
  @@samurais = 0
  def initialize
    super
    @health = 200
    @@samurais += 1
  end
  def deathblow(obj)
    if obj.class.ancestors.include?(Human)
      obj.health = 0
      true
    else
      false
    end
  end
  def meditate
    @health = 200
  end
  def self.howmany
    p "Total Samurais: #{@@samurais}"
    self
  end
end

dude = Samurai.new
bob = Samurai.new
Samurai.howmany
p bob
p dude
bob.deathblow(dude)
p dude
dude.meditate
p dude
