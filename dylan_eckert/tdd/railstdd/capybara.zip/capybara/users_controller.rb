class UsersController < ApplicationController
  def new

  end
  def create
  @user = User.new(params.require(:user).permit(:fname, :lname, :email))
    if @user.save
      redirect_to @user
    else
      flash[:errors] = @user.errors.full_messages
      redirect_to :back
    end
  end
  def show
    @user = User.find(params[:id])
  end
end
