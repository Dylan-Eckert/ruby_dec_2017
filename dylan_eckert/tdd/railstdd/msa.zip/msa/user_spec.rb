require 'rails_helper'

RSpec.describe User do
    it "should not save if fname field is blank" do
      user = User.create(
            fname: '',
            lname: 'chang',
            email: 'schang@codingdojo.com'
        )
      expect(user).to be_invalid
    end

    it "should not save if lname field is blank" do
      user = User.create(
            fname: 'chang',
            lname: '',
            email: 'schang@codingdojo.com'
        )
      expect(user).to be_invalid
    end

    it "should not save if email already exists" do
      user = User.create(
            fname: 'dude',
            lname: 'chang',
            email: 'schang@codingdojo.com'
        )
      user2 = User.create(
            fname: 'bro',
            lname: 'chang',
            email: 'schang@codingdojo.com'
        )
      expect(user2).to be_invalid
    end

    it "should not save if invalid email format" do
      user = User.create(
            fname: 'bro',
            lname: 'chang',
            email: 'schangatcodingdojodotcom'
        )
      expect(user).to be_invalid
    end
end
