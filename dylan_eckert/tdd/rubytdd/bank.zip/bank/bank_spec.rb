require_relative 'bank'
RSpec.describe BankAccount do
  before(:each) do
    # updated this block to create two projects
    @bank1 = BankAccount.new
    @bank2 = BankAccount.new
    @bank1.checkbal = 40
  end
  # - Has a getter method for retrieving the checking account balance
  it 'has a getter for checkbal attribute' do
    expect(@bank1.checkbal).to eq(40)
  end
  # - Has a getter method that retrieves the total account balance
  it 'has a getter for total function' do
    expect(@bank2.showTotal).to eq(0)
  end
  # - Has a function that allows the user to withdraw cash
  it 'has a withdraw cash function' do
    expect(@bank1.withdraw("checking", 20).checkbal).to eq(20)
  end
  # - Raises an error if a user tries to withdraw more money than they have in the account
  it 'has a withdraw cash function with overdraft protection' do
    expect(@bank2.withdraw("checking", 40)).to eq("Not enough funds")
  end
  # - Raises an error when the user attempts to retrieve the total number of bank accounts
  it 'raises an error for total number of bank accounts' do
    expect{@bank1.accounts}.to raise_error(NoMethodError)
  end

  # - Raises an error when the user attempts to set the interest rate
  it 'raises an error for setting interest rate' do
    expect{@bank1.interest = 0}.to raise_error(NoMethodError)
  end
end
